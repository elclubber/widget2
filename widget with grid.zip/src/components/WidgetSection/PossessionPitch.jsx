import React, { useMemo } from "react";
import PitchSvg from "./PitchSvg";
import PossessionHeader from "./PossessionHeader";
import BallPathOverlay from "./BallPathOverlay.jsx";
import "./widget.css";

export default function PossessionPitch({
  leftTeam,
  rightTeam,
  leftPct,
  rightPct,
  maxWidth = 720,
  possTick,
  pathPoints, // e.g. [{x:42,y:60},{x:72,y:38},{x:90,y:34}]
  showAxes = false,
}) {
  const sideInPossession = useMemo(() => {
    if (leftPct === rightPct) return "center";
    return leftPct > rightPct ? "left" : "right";
  }, [leftPct, rightPct]);

  const teamInPossession =
    sideInPossession === "left"
      ? leftTeam
      : sideInPossession === "right"
      ? rightTeam
      : "";

  return (
    <div className="poss-wrap" style={{ "--pitch-max": `${maxWidth}px` }}>
      <PossessionHeader
        side={sideInPossession}
        team={teamInPossession}
        tick={possTick}
      />

      <div className="pitch-area">
        <PitchSvg className="pitch-svg" />
        {Array.isArray(pathPoints) && pathPoints.length >= 2 && (
          <BallPathOverlay points={pathPoints} showAxes={showAxes} />
        )}
        <div className="percent left">
          <span className="value">{leftPct}%</span>
        </div>
        <div className="percent right">
          <span className="value">{rightPct}%</span>
        </div>
      </div>
    </div>
  );
}
