export default function GoalStrip({ lastGoal, maxWidth = 720 }) {
  if (!lastGoal) return null;

  return (
    <div className="goal-strip">
      <div className="goal-row" style={{ "--pitch-max": `${maxWidth}px` }}>
        <div className="goal-pill">
          <span className="label">{lastGoal.label ?? "GOAL"}</span>
          <span className="dot" aria-hidden="true" />
          <span className="team-name">{lastGoal.team}</span>
          <span className="minute">{`${lastGoal.minute}’`}</span>
        </div>
      </div>
    </div>
  );
}
