import React, { useMemo } from "react";
import PossessionHeader from "./PossessionHeader";
import PitchArea from "./PitchArea";
import "./widget.css";

export default function PossessionPitch({
  leftTeam,
  rightTeam,
  leftPct,
  rightPct,
  maxWidth = 720,
  possTick,
}) {
  const sideInPossession = useMemo(() => {
    if (leftPct === rightPct) return "center";
    return leftPct > rightPct ? "left" : "right";
  }, [leftPct, rightPct]);

  const teamInPossession =
    sideInPossession === "left"
      ? leftTeam
      : sideInPossession === "right"
      ? rightTeam
      : "";

  return (
    <div className="poss-wrap" style={{ "--pitch-max": `${maxWidth}px` }}>
      <PossessionHeader
        side={sideInPossession}
        team={teamInPossession}
        tick={possTick}
      />
      <PitchArea leftPct={leftPct} rightPct={rightPct} />
    </div>
  );
}
