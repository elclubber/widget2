export default function PossessionHeader({ side = "center", team = "", tick }) {
  return (
    <div className="poss-header">
      <div className={`poss-badge ${side}`} key={`${side}-${tick}`}>
        {team && <span className="poss-title">Ball Possession</span>}
        <div className="poss-team">
          {team && <span className="dot" />}
          {team && <span className="team-name">{team}</span>}
        </div>
      </div>
    </div>
  );
}
