import { useEffect, useMemo, useState } from "react";

// inputs
const homeTeam = "Z.Brentford";
const awayTeam = "Z.Man City";

/** Simulated frames */
const FRAMES = [
  { left: 35, right: 65, minutes: 5, ballPossTeam: homeTeam },
  { left: 38, right: 62, minutes: 12, ballPossTeam: awayTeam },
  { left: 42, right: 58, minutes: 19, ballPossTeam: homeTeam },
  { left: 48, right: 52, minutes: 27, ballPossTeam: awayTeam },
  { left: 55, right: 45, minutes: 33, ballPossTeam: homeTeam },
  { left: 50, right: 50, minutes: 39, ballPossTeam: awayTeam },
  { left: 44, right: 56, minutes: 44, ballPossTeam: homeTeam },
  { left: 47, right: 53, minutes: 46, ballPossTeam: awayTeam },
  { left: 49, right: 51, minutes: 52, ballPossTeam: homeTeam },
  { left: 53, right: 47, minutes: 58, ballPossTeam: awayTeam },
  { left: 57, right: 43, minutes: 63, ballPossTeam: homeTeam },
  { left: 60, right: 40, minutes: 69, ballPossTeam: awayTeam },
  { left: 62, right: 38, minutes: 75, ballPossTeam: homeTeam },
  { left: 65, right: 35, minutes: 82, ballPossTeam: awayTeam },
  { left: 68, right: 32, minutes: 88, ballPossTeam: homeTeam },
  { left: 70, right: 30, minutes: 90, ballPossTeam: awayTeam },
];

/** Static odds (can be replaced by a real API later) */
const STATIC_ODDS = [
  { label: homeTeam, odds: "1.75", subtitle: "Next Goal" },
  { label: awayTeam, odds: "1.85", subtitle: "Next Goal" },
  { label: "Haaland", odds: "2.75", subtitle: "to score next" },
];

/** Optional: fake goal events so we can show a goal pill */
const GOALS = [
  { minute: 6, team: "Z.Man City" },
  { minute: 27, team: "Z.Brentford" },
];

export default function useFakePossessionFeed(intervalMs = 5000) {
  const [i, setI] = useState(0);

  useEffect(() => {
    const id = setInterval(
      () => setI((n) => (n + 1) % FRAMES.length),
      intervalMs
    );
    return () => clearInterval(id);
  }, [intervalMs]);

  const frame = FRAMES[i];

  // which half we’re in
  const halfCount = frame.minutes <= 45 ? 1 : 2;

  // which team appears on each side (swaps after halftime)
  const leftSideTeam = halfCount === 1 ? homeTeam : awayTeam;
  const rightSideTeam = halfCount === 1 ? awayTeam : homeTeam;

  // possession values
  const leftPossTeamPct = frame.left;
  const rightPossTeamPct = frame.right;

  // who currently has possession (from your frames)
  const ballPossTeam = frame.ballPossTeam;

  // for the header badge alignment (“left” or “right”)
  const headerSide = ballPossTeam === leftSideTeam ? "left" : "right";

  // odds are static for now
  const odds = useMemo(() => STATIC_ODDS, []);

  // compute last goal that has happened up to current minute
  const lastGoal = useMemo(() => {
    const m = frame.minutes;
    const past = [...GOALS].filter((g) => g.minute <= m).pop();
    return past
      ? { label: "GOAL", team: past.team, minute: past.minute }
      : null;
  }, [frame.minutes]);

  return {
    leftSideTeam,
    rightSideTeam,
    ballPossTeam,
    leftPossTeamPct,
    rightPossTeamPct,
    headerSide,
    odds,
    lastGoal,
    frame,
  };
}
